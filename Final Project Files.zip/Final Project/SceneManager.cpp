﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Ryan Orton / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, July 23rd, 2025
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <vector>
#include <iostream>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (image)
    {
        std::cout << "Successfully loaded image:" << filename
            << ", width:" << width
            << ", height:" << height
            << ", channels:" << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            stbi_image_free(image);
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cout << "Could not load image:" << filename << std::endl;
    return false;
}

/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
        glDeleteTextures(1, &m_textureIDs[i].ID);
    m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1, index = 0;
    bool bFound = false;

    while (index < m_loadedTextures && !bFound)
    {
        if (m_textureIDs[index].tag == tag)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else index++;
    }

    return textureID;
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1, index = 0;
    bool bFound = false;

    while (index < m_loadedTextures && !bFound)
    {
        if (m_textureIDs[index].tag == tag)
        {
            textureSlot = index;
            bFound = true;
        }
        else index++;
    }

    return textureSlot;
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.empty())
        return false;

    for (auto& mat : m_objectMaterials)
    {
        if (mat.tag == tag)
        {
            material = mat;
            return true;
        }
    }
    return false;
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float     XrotationDegrees,
    float     YrotationDegrees,
    float     ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1, 0, 0));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0, 1, 0));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0, 0, 1));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);

    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (!m_pShaderManager) return;

    int slot = FindTextureSlot(textureTag);
    if (slot < 0) {
        // Fail-safe: don't enable texturing if tag not found
        m_pShaderManager->setIntValue("bUseTexture", false);
        return;
    }

    m_pShaderManager->setIntValue("bUseTexture", true);
    m_pShaderManager->setSampler2DValue("objectTexture", slot);
}

/***********************************************************
 *  SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager)
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL mat;
    if (FindMaterial(materialTag, mat) && m_pShaderManager)
    {
        m_pShaderManager->setVec3Value("material.ambientColor", mat.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", mat.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
    }
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/**************************************************************/

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // load meshes
    m_basicMeshes->LoadPlaneMesh();    // floor
    m_basicMeshes->LoadCylinderMesh(); // trunk
    m_basicMeshes->LoadConeMesh();     // foliage
    m_basicMeshes->LoadSphereMesh();   // ornaments

    // ----- materials (tuned so nothing is pure black) -----
    m_objectMaterials.clear();

    // Floor (white, lit)
    {
        OBJECT_MATERIAL m{};
        m.tag = "mat_floor";
        m.ambientColor = glm::vec3(0.20f);
        m.ambientStrength = 0.25f;
        m.diffuseColor = glm::vec3(1.0f);
        m.specularColor = glm::vec3(0.25f);
        m.shininess = 16.0f;
        m_objectMaterials.push_back(m);
    }
    // Wood trunk
    {
        OBJECT_MATERIAL m{};
        m.tag = "mat_wood";
        m.ambientColor = glm::vec3(0.25f, 0.20f, 0.15f);
        m.ambientStrength = 0.30f;
        m.diffuseColor = glm::vec3(1.0f);
        m.specularColor = glm::vec3(0.35f);
        m.shininess = 32.0f;
        m_objectMaterials.push_back(m);
    }
    // Pine needles (boost ambient a bit to avoid inner black)
    {
        OBJECT_MATERIAL m{};
        m.tag = "mat_pine";
        m.ambientColor = glm::vec3(0.16f, 0.22f, 0.16f);
        m.ambientStrength = 0.34f;
        m.diffuseColor = glm::vec3(1.0f);
        m.specularColor = glm::vec3(0.20f);
        m.shininess = 24.0f;
        m_objectMaterials.push_back(m);
    }
    // Ornaments (shiny)
    {
        OBJECT_MATERIAL m{};
        m.tag = "mat_ornament";
        m.ambientColor = glm::vec3(0.20f);
        m.ambientStrength = 0.20f;
        m.diffuseColor = glm::vec3(1.0f);
        m.specularColor = glm::vec3(1.0f);
        m.shininess = 64.0f;
        m_objectMaterials.push_back(m);
    }

    // ----- lighting: add an overhead sun + fill + rim + gentle ground bounce -----
    if (m_pShaderManager)
    {
        m_pShaderManager->use();
        m_pShaderManager->setBoolValue(g_UseLightingName, true);

        // Overhead SUN (directly above the tree)
        m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(0.0f, 8.0f, 0.0f));
        m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.12f));
        m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(1.00f, 0.97f, 0.92f));
        m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.65f));
        m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
        m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 1.6f);

        // Fill (camera-left/front)
        m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(-6.0f, 4.5f, -5.0f));
        m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.14f));
        m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.80f, 0.85f, 1.00f));
        m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.30f));
        m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 28.0f);
        m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 1.1f);

        // Rim/back light (subtle separation from background)
        m_pShaderManager->setVec3Value("lightSources[2].position", glm::vec3(0.0f, 3.0f, -6.0f));
        m_pShaderManager->setVec3Value("lightSources[2].ambientColor", glm::vec3(0.06f));
        m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", glm::vec3(0.40f, 0.45f, 0.50f));
        m_pShaderManager->setVec3Value("lightSources[2].specularColor", glm::vec3(0.20f));
        m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 24.0f);
        m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.9f);

        // Ground bounce (reduced so underside isn’t dominant)
        m_pShaderManager->setVec3Value("lightSources[3].position", glm::vec3(0.0f, 1.2f, 0.0f));
        m_pShaderManager->setVec3Value("lightSources[3].ambientColor", glm::vec3(0.05f));
        m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", glm::vec3(0.25f, 0.30f, 0.25f));
        m_pShaderManager->setVec3Value("lightSources[3].specularColor", glm::vec3(0.15f));
        m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 24.0f);
        m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.6f);
    }

    // ----- textures (relative to $(ProjectDir)) -----
    CreateGLTexture("Utilities\\textures\\wood.jpg", "wood"); // cylinder
    CreateGLTexture("Utilities\\textures\\pine.jpg", "pine"); // cones
    BindGLTextures();
}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
    if (m_pShaderManager) {
        m_pShaderManager->use();
        m_pShaderManager->setBoolValue(g_UseLightingName, true);
    }

    glm::vec3 scaleXYZ;
    float     XrotationDegrees = 0.0f;
    float     YrotationDegrees = 0.0f;
    float     ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    /**** Floor (white, lit, no texture) ****/
    scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("mat_floor");
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();

    /**** Trunk (cylinder) — wood.jpg ****/
    scaleXYZ = glm::vec3(0.3f, 1.0f, 0.3f);
    positionXYZ = glm::vec3(0.0f, 0.5f, 0.0f);
    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("mat_wood");
    SetShaderTexture("wood");
    SetTextureUVScale(1.2f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    /**** Foliage (cones) — pine.jpg
     *  Use UNIFORM scaling so normals stay correct with fixed shaders.
     ****/
    {
        const float s[3] = { 1.0f, 0.8f, 0.6f }; // uniform scales
        const float baseY = 1.0f;                // sits on trunk
        float yAcc = 0.0f;

        for (int i = 0; i < 3; ++i)
        {
            float si = s[i];
            scaleXYZ = glm::vec3(si);                         // UNIFORM scaling
            positionXYZ = glm::vec3(0.0f, baseY + yAcc + 0.5f * si, 0.0f);
            SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
            SetShaderMaterial("mat_pine");
            SetShaderTexture("pine");
            SetTextureUVScale(2.0f, 2.0f);
            m_basicMeshes->DrawConeMesh();
            yAcc += si;                                          // stack next cone
        }
    }

    /**** Ornaments (untextured, shiny red) ****/
    {
        std::vector<glm::vec3> ornamentPos = {
            {  0.4f, 2.2f,  0.2f },
            { -0.3f, 2.0f, -0.2f },
            {  0.2f, 1.8f, -0.4f },
            { -0.4f, 1.6f,  0.3f }
        };

        for (auto& pos : ornamentPos)
        {
            scaleXYZ = glm::vec3(0.1f);
            positionXYZ = pos;
            SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
            SetShaderMaterial("mat_ornament");
            SetShaderColor(1.0f, 0.0f, 0.0f, 1.0f);
            m_basicMeshes->DrawSphereMesh();
        }
    }
}







